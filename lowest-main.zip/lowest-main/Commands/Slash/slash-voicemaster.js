const { SlashCommandBuilder, PermissionsBitField, ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const DB = require("../../Database/Localdb/voiceMasterDB");
const emojis = require('../../emojis.json');

const COLOR = "#FFFFFF";

module.exports = {
    data: new SlashCommandBuilder()
        .setName("voicemaster")
        .setDescription("Configure Voice Master")
        .addSubcommand(s => s.setName("setup").setDescription("Create a voice channel system"))
        .addSubcommand(s => s.setName("remove").setDescription("Delete currently configured system")),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setColor(0xfbd03c)
                    .setDescription(`${emojis.warning} ${interaction.user}: Only **administrators** can use this command.`)
                ],
                ephemeral: false
            });
        }

        const guild = interaction.guild;
        const sub = interaction.options.getSubcommand();

        if (sub === "setup") {
            const category = await guild.channels.create({
                name: "Voice Channels",
                type: ChannelType.GuildCategory
            });

            const create = await guild.channels.create({
                name: "Join to create",
                type: ChannelType.GuildVoice,
                parent: category.id
            });

            const iface = await guild.channels.create({
                name: "interface",
                type: ChannelType.GuildText,
                parent: category.id
            });

            DB.set(guild.id, {
                category: category.id,
                create: create.id,
                interface: iface.id
            });

            const panel = new EmbedBuilder()
                .setColor(COLOR)
                .setTitle("VoiceMaster Interface")
                .setAuthor({
                    name: interaction.client.user.username,
                    iconURL: interaction.client.user.displayAvatarURL()
                })
                .setDescription(
                    "Click the buttons below to control your voice channel\n" +
                    "**Button Usage:**\n" +
                    "<:lock:1441487505286234252> [Lock](https://discord.gg/SDCTPsRZmx) — Lock the voice channel\n" +
                    "<:unlock:1441487621678305393> [Unlock](https://discord.gg/SDCTPsRZmx) — Unlock the voice channel\n" +
                    "<:ghost:1441488167529218299> [Hide](https://discord.gg/SDCTPsRZmx) — Hide the voice channel\n" +
                    "<:unghost:1441488094762369190> [Reveal](https://discord.gg/SDCTPsRZmx) — Reveal the voice channel\n" +
                    "<:disconnect:1441488320063340597> [Disconnect](https://discord.gg/SDCTPsRZmx) — Disconnect a member\n" +
                    "<:Ownership:1447346504649019436> [Claim](https://discord.gg/SDCTPsRZmx) — Claim the voice channel\n" +
                    "<:b_hastag:1447347067813888143> [Name edit](https://discord.gg/SDCTPsRZmx)— Edit the channel name\n" +
                    "<:info:1441488877230756123> [Info](https://discord.gg/SDCTPsRZmx) — View channel info\n" +
                    "<:increase:1441489046399484085> [Increase](https://discord.gg/SDCTPsRZmx) — Increase the user limit\n" +
                    "<:decrease:1441488996411768842> [Decrease](https://discord.gg/SDCTPsRZmx) — Decrease the user limit"
                );

            const row1 = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId("vm_lock").setEmoji("1441487505286234252").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId("vm_unlock").setEmoji("1441487621678305393").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId("vm_hide").setEmoji("1441488167529218299").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId("vm_unhide").setEmoji("1441488094762369190").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId("vm_kick").setEmoji("1441488320063340597").setStyle(ButtonStyle.Secondary)
            );

            const row2 = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId("vm_claim").setEmoji("1447346504649019436").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId("vm_activity").setEmoji("1447347067813888143").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId("vm_info").setEmoji("1441488877230756123").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId("vm_plus").setEmoji("1441489046399484085").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId("vm_minus").setEmoji("1441488996411768842").setStyle(ButtonStyle.Secondary)
            );

            await iface.send({ embeds: [panel], components: [row1, row2] });

            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setColor(0xa4ec77)
                    .setDescription(`${emojis.approve} ${interaction.user}: The voicemaster system has been configured`)
                ]
            });
        }

        if (sub === "remove") {
            const data = DB.get(guild.id);
            if (!data) {
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xff6464)
                        .setDescription(`${emojis.deny} ${interaction.user}: No VoiceMaster setup found.`)
                    ]
                });
            }

            try {
                const category = await guild.channels.fetch(data.category);
                if (category) {
                    const children = guild.channels.cache.filter(c => c.parentId === category.id);
                    for (const child of children.values()) {
                        await child.delete().catch(() => {});
                    }
                    await category.delete().catch(() => {});
                }
            } catch (error) {
            }

            DB.remove(guild.id);

            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setColor(0xa4ec77)
                    .setDescription(`${emojis.approve} ${interaction.user}: VoiceMaster successfully deactivated and channels deleted.`)
                ]
            });
        }
    },
};