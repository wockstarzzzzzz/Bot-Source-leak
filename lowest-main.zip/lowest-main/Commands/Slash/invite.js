const { SlashCommandBuilder, PermissionsBitField, MessageFlags } = require('discord.js');

module.exports = {
    category: 'general',
    data: new SlashCommandBuilder()
        .setName('invite')
        .setDescription('Sends the bot invite link'),

    async execute(interaction) {

        if (!interaction.guild) {
            return interaction.reply({
                content: 'This command can only be used in a server.',
                flags: MessageFlags.Ephemeral
            });
        }

        if (
            !interaction.guild.members.me
                .permissionsIn(interaction.channel)
                .has(PermissionsBitField.Flags.SendMessages)
        ) {
            return interaction.reply({
                content: 'I do not have permission to send messages in this channel.',
                flags: MessageFlags.Ephemeral
            });
        }

        try {
            const inviteLink = `https://discord.com/oauth2/authorize?client_id=${interaction.client.user.id}`;

            const mensaje = `Invite the bot using the button below!\n${inviteLink}`;

            await interaction.reply(mensaje);

        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: 'An error occurred while trying to send the message.',
                flags: MessageFlags.Ephemeral
            });
        }
    }
};
