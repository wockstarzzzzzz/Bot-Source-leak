const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, MessageFlags } = require('discord.js');
const AutorolSchema = require('../../../Database/Schemas/autorol');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autorol')
        .setDescription('Configure automatic roles for new members')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
        .addStringOption(option =>
            option.setName('action')
                .setDescription('Action to perform')
                .setRequired(true)
                .addChoices(
                    { name: 'Set', value: 'set' },
                    { name: 'Remove', value: 'remove' },
                    { name: 'View', value: 'view' }
                ))
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('Role to assign automatically')
                .setRequired(false)),

    async execute(interaction) {
        const action = interaction.options.getString('action');
        const role = interaction.options.getRole('role');

        try {
            switch (action) {
                case 'set':
                    if (!role) {
                        return interaction.reply({
                            content: '> You must specify a role',
                            flags: MessageFlags.Ephemeral
                        });
                    }

                    if (role.position >= interaction.guild.members.me.roles.highest.position) {
                        return interaction.reply({
                            content: '> I cannot assign this role, it is higher than or equal to my highest role.',
                            flags: MessageFlags.Ephemeral
                        });
                    }

                    await AutorolSchema.findOneAndUpdate(
                        { guildId: interaction.guild.id },
                        { roleId: role.id },
                        { upsert: true, new: true }
                    );

                    const embedSet = new EmbedBuilder()
                        .setColor('#2b2d31')
                        .setTitle('> Autorol Configured')
                        .addFields(
                            {
                                name: '> Action',
                                value: '> Set',
                                inline: true
                            },
                            {
                                name: '> Role',
                                value: `> ${role}`,
                                inline: true
                            },
                            {
                                name: '> Role ID',
                                value: `> ${role.id}`,
                                inline: true
                            },
                            {
                                name: '> Instruction',
                                value: '> New members will receive this role automatically',
                                inline: false
                            }
                        )
                        .setTimestamp();

                    await interaction.reply({ embeds: [embedSet], flags: MessageFlags.Ephemeral });
                    break;

                case 'remove':
                    await AutorolSchema.findOneAndDelete({ guildId: interaction.guild.id });

                    const embedRemove = new EmbedBuilder()
                        .setColor('#2b2d31')
                        .setTitle('> Autorol Removed')
                        .addFields(
                            {
                                name: '> Action',
                                value: '> Removed',
                                inline: true
                            },
                            {
                                name: '> Status',
                                value: '> New members will no longer receive an automatic role',
                                inline: false
                            }
                        )
                        .setTimestamp();

                    await interaction.reply({ embeds: [embedRemove], flags: MessageFlags.Ephemeral });
                    break;

                case 'view':
                    const data = await AutorolSchema.findOne({ guildId: interaction.guild.id });

                    if (data) {
                        const currentRole = await interaction.guild.roles.fetch(data.roleId).catch(() => null);

                        const embedView = new EmbedBuilder()
                            .setColor('#2b2d31')
                            .setTitle('> Current Autorol')
                            .addFields(
                                {
                                    name: '> Status',
                                    value: '> Configured',
                                    inline: true
                                },
                                {
                                    name: '> Role',
                                    value: currentRole ? `> ${currentRole}` : '> Deleted Role',
                                    inline: true
                                },
                                {
                                    name: '> Role ID',
                                    value: `> ${data.roleId}`,
                                    inline: true
                                }
                            )
                            .setTimestamp();

                        await interaction.reply({ embeds: [embedView], flags: MessageFlags.Ephemeral });
                    } else {
                        const embedNoConfig = new EmbedBuilder()
                            .setColor('#2b2d31')
                            .setTitle('> Current Autorol')
                            .addFields(
                                {
                                    name: '> Status',
                                    value: '> Not configured',
                                    inline: false
                                },
                                {
                                    name: '> Information',
                                    value: '> Use /autorol set [role] to configure',
                                    inline: false
                                }
                            )
                            .setTimestamp();

                        await interaction.reply({ embeds: [embedNoConfig], flags: MessageFlags.Ephemeral });
                    }
                    break;
            }
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: 'An error occurred with the command.', flags: MessageFlags.Ephemeral });
        }
    }
};
