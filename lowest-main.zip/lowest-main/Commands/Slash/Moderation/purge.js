const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, MessageFlags } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('purge')
        .setDescription('Deletes a specified amount of messages')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Number of messages to delete (1-100)')
                .setMinValue(1)
                .setMaxValue(100)
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
    async execute(interaction) {
        const amount = interaction.options.getInteger('amount');

        await interaction.channel.bulkDelete(amount, true).then(messages => {
            const embed = new EmbedBuilder()
                .setDescription(`> Successfully deleted ${messages.size} messages.`)
                .setColor('#2b2d31');

            interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }).catch(error => {
            console.error(error);
            interaction.reply({ content: 'There was an error trying to purge messages in this channel!', flags: MessageFlags.Ephemeral });
        });
    },
};
