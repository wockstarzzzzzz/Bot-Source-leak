const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, MessageFlags } = require('discord.js');
const ms = require('ms');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('timeout')
        .setDescription('Timeouts a member')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('The member to timeout')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Duration of timeout (e.g. 1h, 5m)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the timeout'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
    async execute(interaction) {
        const target = interaction.options.getMember('target');
        const duration = interaction.options.getString('duration');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        if (!target) {
            return interaction.reply({ content: 'Member not found.', flags: MessageFlags.Ephemeral });
        }

        if (!target.moderatable) {
            return interaction.reply({ content: 'I cannot timeout this user. They may have higher roles than me.', flags: MessageFlags.Ephemeral });
        }

        const time = ms(duration);
        if (!time) {
            return interaction.reply({ content: 'Invalid duration specified.', flags: MessageFlags.Ephemeral });
        }

        try {
            await target.timeout(time, reason);

            const embed = new EmbedBuilder()
                .setTitle('> Member Timeout')
                .setDescription(`> ${target} has been timed out.`)
                .addFields(
                    { name: '> Duration', value: `> ${duration}`, inline: true },
                    { name: '> Reason', value: `> ${reason}`, inline: true }
                )
                .setColor('#2b2d31')
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: 'There was an error trying to timeout this member.', flags: MessageFlags.Ephemeral });
        }
    },
};

