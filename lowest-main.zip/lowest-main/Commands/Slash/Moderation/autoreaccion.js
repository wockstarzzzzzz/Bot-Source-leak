const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType, MessageFlags } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autoreaccion')
        .setDescription('Configure auto-reactions on specific messages')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addStringOption(option =>
            option.setName('action')
                .setDescription('Action to perform')
                .setRequired(true)
                .addChoices(
                    { name: 'Add', value: 'add' },
                    { name: 'Remove', value: 'remove' },
                    { name: 'List', value: 'list' }
                ))
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel where the message is')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .addStringOption(option =>
            option.setName('message_id')
                .setDescription('ID of the message')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('emoji')
                .setDescription('Emoji to react with (Required for Add/Remove)')
                .setRequired(false)),

    async execute(interaction) {
        const action = interaction.options.getString('action');
        const channel = interaction.options.getChannel('channel');
        const messageId = interaction.options.getString('message_id');
        const emoji = interaction.options.getString('emoji');

        try {
            const message = await channel.messages.fetch(messageId).catch(() => null);

            if (!message) {
                return interaction.reply({
                    content: '> Message not found in the specified channel.',
                    flags: MessageFlags.Ephemeral
                });
            }

            switch (action) {
                case 'add':
                    if (!emoji) return interaction.reply({ content: '> You must specify an emoji to add.', flags: MessageFlags.Ephemeral });
                    await message.react(emoji).catch(e => {
                        throw new Error('Failed to react. Ensure I have permissions and the emoji is valid.');
                    });

                    const embedAdd = new EmbedBuilder()
                        .setColor('#2b2d31')
                        .setTitle('> Auto-Reaction Configured')
                        .addFields(
                            {
                                name: '> Action',
                                value: '> Added',
                                inline: true
                            },
                            {
                                name: '> Channel',
                                value: `> ${channel}`,
                                inline: true
                            },
                            {
                                name: '> Emoji',
                                value: `> ${emoji}`,
                                inline: true
                            },
                            {
                                name: '> Message ID',
                                value: `> ${messageId}`,
                                inline: false
                            }
                        )
                        .setTimestamp();

                    await interaction.reply({ embeds: [embedAdd], flags: MessageFlags.Ephemeral });
                    break;

                case 'remove':
                    if (!emoji) return interaction.reply({ content: '> You must specify an emoji to remove.', flags: MessageFlags.Ephemeral });

                    const reaction = message.reactions.cache.get(emoji) ||
                        message.reactions.cache.find(r => r.emoji.toString() === emoji);

                    if (reaction) {
                        await reaction.remove().catch(() => { });
                    }

                    const embedRemove = new EmbedBuilder()
                        .setColor('#2b2d31')
                        .setTitle('> Auto-Reaction Removed')
                        .addFields(
                            {
                                name: '> Action',
                                value: '> Removed',
                                inline: true
                            },
                            {
                                name: '> Emoji',
                                value: `> ${emoji}`,
                                inline: true
                            }
                        )
                        .setTimestamp();

                    await interaction.reply({ embeds: [embedRemove], flags: MessageFlags.Ephemeral });
                    break;

                case 'list':
                    const reactionsList = message.reactions.cache;
                    const list = reactionsList.map(r => r.emoji.toString()).join(', ') || '> No reactions';

                    const embedList = new EmbedBuilder()
                        .setColor('#2b2d31')
                        .setTitle('> Message Reactions')
                        .addFields(
                            {
                                name: '> Message ID',
                                value: `> ${messageId}`,
                                inline: true
                            },
                            {
                                name: '> Total Reactions',
                                value: `> ${reactionsList.size}`,
                                inline: true
                            },
                            {
                                name: '> Reactions',
                                value: `> ${list}`,
                                inline: false
                            }
                        )
                        .setTimestamp();

                    await interaction.reply({ embeds: [embedList], flags: MessageFlags.Ephemeral });
                    break;
            }

        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: `> Error configuring auto-reaction: ${error.message}`,
                flags: MessageFlags.Ephemeral
            });
        }
    }
};
