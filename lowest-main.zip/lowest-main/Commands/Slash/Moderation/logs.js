const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder, MessageFlags } = require('discord.js');
const LogsSchema = require('../../../Database/Schemas/logs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('logs')
        .setDescription('Configure the logging system')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel to send logs to')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .addStringOption(option =>
            option.setName('type')
                .setDescription('Type of logs to enable')
                .setRequired(true)
                .addChoices(
                    { name: 'All', value: 'all' },
                    { name: 'Moderation', value: 'mod' },
                    { name: 'Members', value: 'members' },
                    { name: 'Channels', value: 'channels' },
                    { name: 'Roles', value: 'roles' },
                    { name: 'Messages', value: 'messages' }
                )),

    async execute(interaction) {
        const channel = interaction.options.getChannel('channel');
        const type = interaction.options.getString('type');

        try {
            let logData = await LogsSchema.findOne({ guildId: interaction.guild.id });

            if (logData) {
                logData.channelId = channel.id;
                if (!logData.types.includes(type)) {
                    if (type === 'all') {
                        logData.types = ['all', 'mod', 'members', 'channels', 'roles', 'messages'];
                    } else {
                        if (!logData.types.includes(type)) logData.types.push(type);
                    }
                }
                await logData.save();
            } else {
                let types = [type];
                if (type === 'all') {
                    types = ['all', 'mod', 'members', 'channels', 'roles', 'messages'];
                }

                logData = await LogsSchema.create({
                    guildId: interaction.guild.id,
                    channelId: channel.id,
                    types: types
                });
            }

            const tiposDesc = {
                'all': 'All events',
                'mod': 'Moderation (bans, kicks, warns)',
                'members': 'Members (join, leave, updates)',
                'channels': 'Channels (create, edit, delete)',
                'roles': 'Roles (create, edit, delete)',
                'messages': 'Messages (edit, delete)'
            };

            const embed = new EmbedBuilder()
                .setColor('#2b2d31')
                .setTitle('> Logging System Configured')
                .addFields(
                    {
                        name: '> Channel',
                        value: `> ${channel}`,
                        inline: true
                    },
                    {
                        name: '> Type',
                        value: `> ${tiposDesc[type]}`,
                        inline: true
                    },
                    {
                        name: '> Status',
                        value: '> Active',
                        inline: true
                    },
                    {
                        name: '> Information',
                        value: '> Logs will be sent to this channel automatically',
                        inline: false
                    }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });

        } catch (error) {
            console.error(error);
            await interaction.reply({ content: 'An error occurred while saving the configuration.', flags: MessageFlags.Ephemeral });
        }
    }
};
