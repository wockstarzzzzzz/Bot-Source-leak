const { EmbedBuilder, PermissionsBitField, SlashCommandBuilder } = require("discord.js");
const emojis = require('../../../emojis.json');
const config = require('../../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("mute")
        .setDescription("Mutes a user using Discord timeout with a specified duration and reason.")
        .addUserOption(option => 
            option.setName('user')
                .setDescription('The user to mute')
                .setRequired(true))
        .addStringOption(option => 
            option.setName('duration')
                .setDescription('The duration of the mute')
                .setRequired(true)
                .addChoices(
                    { name: '60 seconds', value: '60s' },
                    { name: '5 minutes', value: '5m' },
                    { name: '10 minutes', value: '10m' },
                    { name: '1 hour', value: '1h' },
                    { name: '1 day', value: '1d' },
                    { name: '1 week', value: '7d' }
                ))
        .addStringOption(option => 
            option.setName('reason')
                .setDescription('The reason for muting')
                .setRequired(false)),
    cat: 'mod',
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.warning}`)
                .setDescription("You don't have permission to mute members.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.warning}`)
                .setDescription("I don't have permission to mute members.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const member = interaction.options.getMember('user');
        if (!member) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.deny}`)
                .setDescription("Couldn't find that user in the guild.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (!member.moderatable) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.deny}`)
                .setDescription("I can't mute that user.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (member.id === interaction.user.id) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.deny}`)
                .setDescription("You can't mute yourself.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const timeStr = interaction.options.getString('duration');
        const timeoutMs = parseTime(timeStr);
        if (!timeoutMs) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.deny}`)
                .setDescription("Invalid time format.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (timeoutMs > 28 * 24 * 60 * 60 * 1000) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.deny}`)
                .setDescription("Timeout duration can't exceed 28 days.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const reason = interaction.options.getString('reason') || "No reason provided";

        try {
            await member.timeout(timeoutMs, reason);

            const embed = new EmbedBuilder()
                .setColor(`${config.approve}`)
                .setTitle("> User Muted")
                .setDescription(`> **User:** <@${member.id}>`)
                .addFields(
                    { name: '> Moderator', value: `<@${interaction.user.id}>`, inline: false },
                    { name: '> Duration', value: `> ${timeStr}`, inline: true },
                    { name: '> Reason', value: `> ${reason}`, inline: true }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed]});
        } catch (error) {
            console.error(error);
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.deny}`)
                .setDescription("Failed to mute the user.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};

function parseTime(timeStr) {
    const regex = /^(\d+)([smhd])$/i;
    const match = timeStr.match(regex);
    if (!match) return null;

    const amount = parseInt(match[1]);
    const unit = match[2].toLowerCase();

    switch (unit) {
        case 's': return amount * 1000;
        case 'm': return amount * 60 * 1000;
        case 'h': return amount * 60 * 60 * 1000;
        case 'd': return amount * 24 * 60 * 60 * 1000;
        default: return null;
    }
}