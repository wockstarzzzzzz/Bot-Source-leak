const { EmbedBuilder, PermissionsBitField, SlashCommandBuilder } = require("discord.js");
const emojis = require('../../../emojis.json');
const config = require('../../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("unmute")
        .setDescription("Unmutes a user by removing the Discord timeout with a specified reason.")
        .addUserOption(option => 
            option.setName('user')
                .setDescription('The user to unmute')
                .setRequired(true))
        .addStringOption(option => 
            option.setName('reason')
                .setDescription('The reason for unmuting')
                .setRequired(false)),
    cat: 'mod',
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.warning}`)
                .setDescription("You don't have permission to unmute members.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.warning}`)
                .setDescription("I don't have permission to unmute members.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const member = interaction.options.getMember('user');
        if (!member) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.deny}`)
                .setDescription("Couldn't find that user in the guild.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (!member.moderatable) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.deny}`)
                .setDescription("I can't unmute that user.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (member.id === interaction.user.id) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.deny}`)
                .setDescription("You can't unmute yourself.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        if (!member.isCommunicationDisabled()) {
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.deny}`)
                .setDescription("That user is not muted.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const reason = interaction.options.getString('reason') || "No reason provided";

        try {
            await member.timeout(null, reason);

            const embed = new EmbedBuilder()
                .setColor(`${config.approve}`)
                .setTitle("> User Unmuted")
                .setDescription(`> **User:** <@${member.id}>\n> **Moderator:** <@${interaction.user.id}>`)
                .addFields(
                    { name: '> Reason', value: `> ${reason}`, inline: true }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed]});
        } catch (error) {
            console.error(error);
            const errorEmbed = new EmbedBuilder()
                .setColor(`${config.deny}`)
                .setDescription("Failed to unmute the user.");
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};