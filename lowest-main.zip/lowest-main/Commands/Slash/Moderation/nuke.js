const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType, ButtonBuilder, ActionRowBuilder, ButtonStyle, ComponentType, MessageFlags } = require('discord.js');
const emojis = require('../../../emojis.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('nuke')
        .setDescription('Nukes (clones and deletes) the current channel')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return interaction.reply({ content: "You do not have permission to use this command.", flags: MessageFlags.Ephemeral });
        }

        if (interaction.channel.type !== ChannelType.GuildText) {
            return interaction.reply({ content: 'This command can only be used in text channels.', flags: MessageFlags.Ephemeral });
        }

        const confirmButton = new ButtonBuilder()
            .setCustomId('confirm_nuke')
            .setLabel('Accept')
            .setStyle(ButtonStyle.Success);

        const row = new ActionRowBuilder()
            .addComponents(confirmButton);

        const confirmEmbed = new EmbedBuilder()
            .setColor('#2b2d31')
            .setDescription('Are you sure you want to nuke this channel?');

        const response = await interaction.reply({
            embeds: [confirmEmbed],
            components: [row]
        });

        const collector = response.createMessageComponentCollector({
            componentType: ComponentType.Button,
            time: 30000
        });

        collector.on('collect', async i => {
            if (i.user.id !== interaction.user.id) {
                return i.reply({ content: "You cannot confirm this nuke command.", flags: MessageFlags.Ephemeral });
            }

            const channelInfo = {
                name: interaction.channel.name,
                type: interaction.channel.type,
                position: interaction.channel.position,
                parentId: interaction.channel.parentId,
                permissionOverwrites: interaction.channel.permissionOverwrites.cache.map(overwrite => ({
                    id: overwrite.id,
                    type: overwrite.type,
                    allow: overwrite.allow,
                    deny: overwrite.deny,
                }))
            };

            try {
                await interaction.channel.delete(`Channel nuked by ${interaction.user.tag}`);

                const newChannel = await interaction.guild.channels.create({
                    name: channelInfo.name,
                    type: channelInfo.type,
                    parent: channelInfo.parentId,
                    position: channelInfo.position,
                    permissionOverwrites: channelInfo.permissionOverwrites,
                });

                const confirmationEmbed = new EmbedBuilder()
                    .setColor('#2b2d31')
                    .setDescription(`> ${emojis.approve || '✅'} This channel has been nuked by ${interaction.user}`);

                const confirmationMessage = await newChannel.send({ embeds: [confirmationEmbed] });
                setTimeout(() => {
                    confirmationMessage.delete().catch(() => { });
                }, 5000);

            } catch (error) {
                console.error(error);
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                interaction.editReply({ content: 'Nuke timed out.', components: [], embeds: [] }).catch(() => { });
            }
        });
    },
};