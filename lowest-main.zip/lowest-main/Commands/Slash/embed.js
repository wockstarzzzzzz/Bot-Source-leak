const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField, MessageFlags } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('embed')
        .setDescription('Create an embed')
        .addStringOption(option =>
            option.setName('title')
                .setDescription('The title of the embed')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('description')
                .setDescription('The description of the embed')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('color')
                .setDescription('The color of the embed in hex format')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('thumbnail')
                .setDescription('The thumbnail URL of the embed')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('image')
                .setDescription('The image URL of the embed')
                .setRequired(false))
        .addBooleanOption(option =>
            option.setName('timestamp')
                .setDescription('Whether to include timestamp in the embed')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('footer')
                .setDescription('The footer text of the embed')
                .setRequired(false)),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return interaction.reply({ content: 'You do not have permission to use this command.', flags: MessageFlags.Ephemeral });
        }

        const title = interaction.options.getString('title');
        const description = interaction.options.getString('description');
        const color = interaction.options.getString('color');
        const thumbnail = interaction.options.getString('thumbnail');
        const image = interaction.options.getString('image');
        const timestamp = interaction.options.getBoolean('timestamp');
        const footer = interaction.options.getString('footer');

        let embedColor = '#FFFFFF';
        if (color && /^#[0-9A-Fa-f]{6}$/.test(color)) {
            embedColor = color;
        }

        const embed = new EmbedBuilder()
            .setColor(embedColor);

        if (title) embed.setTitle(title);
        if (description) embed.setDescription(description);
        if (thumbnail) embed.setThumbnail(thumbnail);
        if (image) embed.setImage(image);
        if (footer) embed.setFooter({ text: footer });
        if (timestamp) embed.setTimestamp();

        const embedData = embed.data;
        if (!embedData.title && !embedData.description && !embedData.thumbnail && !embedData.image && !embedData.footer && !embedData.timestamp) {
            return interaction.reply({ content: 'You must provide at least one embed element (title, description, thumbnail, image, footer, or timestamp).', flags: MessageFlags.Ephemeral });
        }

        await interaction.reply({
            content: 'Embed created successfully!',
            flags: MessageFlags.Ephemeral
        });

        await interaction.channel.send({
            embeds: [embed]
        });
    },
};