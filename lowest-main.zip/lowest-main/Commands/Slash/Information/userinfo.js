const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('userinfo')
        .setDescription('Displays information about a user')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('The user to get information from')
                .setRequired(false)),
    async execute(interaction) {
        const target = interaction.options.getMember('target') || interaction.member;
        const user = target.user;

        const roles = target.roles.cache
            .filter(r => r.name !== '@everyone')
            .sort((a, b) => b.position - a.position)
            .map(r => r)
            .join(' ') || 'None';

        const embed = new EmbedBuilder()
            .setColor(target.displayHexColor === '#000000' ? '#2b2d31' : target.displayHexColor)
            .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL() })
            .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 512 }))
            .addFields(
                { name: 'Identity', value: `> **Tag:** ${user.tag}\n> **ID:** ${user.id}\n> **Mention:** ${target}`, inline: true },
                { name: 'Dates', value: `> **Created:** <t:${Math.floor(user.createdTimestamp / 1000)}:R>\n> **Joined:** <t:${Math.floor(target.joinedTimestamp / 1000)}:R>`, inline: true },
                { name: `Roles [${target.roles.cache.size - 1}]`, value: roles, inline: false }
            )
            .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};
